<template>
  <div class="grid-cols-2 scrollbar-hide">
    <div class="flex items-center justify-center bg-gray-900">
      <div class="container px-4 mx-auto">
        <div class="flex items-center py-10">
          <h1 class="text-3xl font-bold text-gray-100">Product List</h1>
          <div class="flex justify-end grow">
            <nuxt-link to="/products/create" class="px-4 py-2 font-bold text-white transition-colors duration-300 ease-in-out bg-indigo-600 rounded hover:bg-indigo-500">Add Product</nuxt-link>
          </div>
        </div>
        <div v-if="state.products.length" class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          <div v-for="product in state.products" :key="product.id" class="flex flex-col p-4 bg-gray-800 rounded-lg shadow-sm ring-1 ring-gray-700 shadow-gray-700 bg-none">
            <!-- Render product details -->
            <!-- Ensure product properties match your API response -->
            <div>
              <img :src="product.photo" alt="Product Image" class="object-cover w-full h-32 rounded">
            </div>
            <div class="flex flex-col items-start flex-grow w-full mt-4">
              <h2 class="p-2 text-xl font-bold text-gray-100">{{ product.name }}</h2>
              <p class="p-2 text-gray-400">{{ product.description }}</p>
              <div class="p-2 text-gray-100">Quantity: {{ product.quantity }}</div>
              <div class="p-2 text-gray-100">Price: ₱{{ product.price }}</div>
              <div class="flex w-full mt-auto">
                <nuxt-link :to="`/products/${product.id}`">
                  <button class="px-4 py-2 font-bold text-gray-100 transition-colors duration-300 ease-in-out bg-indigo-600 rounded hover:bg-indigo-500 hover:text-gray-100">Update</button>
                </nuxt-link>
              </div>
            </div>
          </div>
        </div>
        <div v-else-if="!state.products.length" class="flex items-center justify-center min-h-full text-center text-gray-100">
          <!-- Display a message if no products are found -->
          <div class="space-y-4">
            <div class="flex justify-center">
              <FaceFrownIcon class="text-red-600 h-60 w-60" aria-hidden="true"/>
            </div>
            <h3 class="text-xl font-semibold">No products found</h3>
            <p class="text-gray-400">We couldn't find any products at the moment.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { productsService } from '@/components/api/admin/ProductsService'
import { FaceFrownIcon } from '@heroicons/vue/24/outline'

const state = ref({
  products: [], // Initialize products array
  error: null // Initialize error to null
})



async function fetchProducts() {
  try {
    const params = {} // Initialize params object
    const response = await productsService.getProducts(params)
    console.log('Products Response:', response); // Log the response
    state.products = response // Assign fetched products to state
  } catch (error) {
    console.error('Error fetching products:', error); // Log any errors
    state.error = error // Handle errors
  }
}

onMounted(() => {
  fetchProducts()
})
</script>
